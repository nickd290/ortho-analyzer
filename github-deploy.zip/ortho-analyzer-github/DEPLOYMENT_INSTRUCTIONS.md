# GitHub Pages Deployment Instructions

Follow these steps to deploy your Orthodontic Case Analyzer to GitHub Pages and get a live URL.

## Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Repository name: `ortho-analyzer` (or any name you prefer)
3. Description: "AI-powered orthodontic case analysis"
4. Choose **Public** (required for free GitHub Pages)
5. Do NOT initialize with README
6. Click "Create repository"

## Step 2: Upload Files

### Option A: GitHub Web Interface (Easiest)

1. On your new repository page, click **"uploading an existing file"**
2. Drag and drop these two files:
   - `index.html`
   - `README.md`
3. Scroll down and click **"Commit changes"**

### Option B: GitHub Desktop

1. Download GitHub Desktop: https://desktop.github.com/
2. Clone your new repository
3. Copy `index.html` and `README.md` into the repository folder
4. Commit and push changes

### Option C: Git Command Line

```bash
# In the ortho-analyzer-github folder
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ortho-analyzer.git
git push -u origin main
```

## Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** (top right)
3. Click **Pages** (left sidebar)
4. Under "Source", select **Deploy from a branch**
5. Under "Branch", select **main** and **/ (root)**
6. Click **Save**

## Step 4: Access Your Live App

After 1-2 minutes, your app will be live at:

```
https://YOUR-USERNAME.github.io/ortho-analyzer/
```

Replace `YOUR-USERNAME` with your actual GitHub username.

Example: If your username is `drsmith`, your URL will be:
```
https://drsmith.github.io/ortho-analyzer/
```

## Step 5: Get Your URL

1. Go back to **Settings → Pages**
2. At the top, you'll see: **"Your site is live at https://..."**
3. Click that URL to open your app
4. Bookmark it for easy access

## Troubleshooting

### "404 - File not found"
- Wait 2-3 minutes for GitHub Pages to build
- Refresh the page
- Make sure you uploaded `index.html` (not `ortho-analyzer-pro.html`)

### "Repository not found"
- Make sure repository is Public, not Private
- Check Settings → Pages is enabled

### "Page not updating"
- Go to Actions tab to see deployment status
- May take 1-2 minutes to reflect changes
- Try hard refresh (Ctrl+Shift+R or Cmd+Shift+R)

## Updating Your App

To update the app later:

1. Edit `index.html` on GitHub (click file, then pencil icon)
2. Make your changes
3. Commit changes
4. Wait 1-2 minutes for deployment
5. Refresh your live URL

## Making Repository Private

GitHub Pages requires a **public** repository for free accounts. If you need privacy:

1. Upgrade to GitHub Pro ($4/month)
2. Then you can make the repository private
3. GitHub Pages will still work

OR

1. Use the downloaded HTML file locally
2. Don't deploy to GitHub Pages
3. Just open the file on your computer

## Custom Domain (Optional)

Want a custom URL like `ortho.yourdomain.com`?

1. Buy a domain (Namecheap, GoDaddy, etc.)
2. Go to Settings → Pages → Custom domain
3. Enter your domain
4. Configure DNS settings (GitHub provides instructions)

## Need Help?

- GitHub Pages docs: https://docs.github.com/pages
- Check repository Actions tab for deployment status
- Make sure `index.html` is in the root folder

---

## Quick Summary

1. Create repo on GitHub
2. Upload `index.html` and `README.md`
3. Enable Pages in Settings
4. Wait 2 minutes
5. Visit: `https://YOUR-USERNAME.github.io/ortho-analyzer/`

That's it! 🚀
