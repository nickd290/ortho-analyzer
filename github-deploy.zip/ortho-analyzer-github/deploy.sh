#!/bin/bash

# Orthodontic Analyzer - GitHub Deployment Script
# For GitHub user: nickd290

echo "🚀 Deploying Orthodontic Analyzer to GitHub..."
echo ""

# Initialize git repository
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit - Orthodontic Case Analyzer Pro"

# Rename branch to main
git branch -M main

# Add remote repository
git remote add origin https://github.com/nickd290/ortho-analyzer.git

# Push to GitHub
git push -u origin main

echo ""
echo "✅ Deployment complete!"
echo ""
echo "Next steps:"
echo "1. Go to: https://github.com/nickd290/ortho-analyzer"
echo "2. Click Settings → Pages"
echo "3. Source: Deploy from a branch"
echo "4. Branch: main, / (root)"
echo "5. Click Save"
echo ""
echo "Your live URL will be:"
echo "https://nickd290.github.io/ortho-analyzer/"
echo ""
echo "Wait 2-3 minutes, then visit your URL!"
